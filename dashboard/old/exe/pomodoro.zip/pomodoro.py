import os
import tkinter as tk
from tkinter import ttk
from datetime import timedelta
import json
import platform
import pygame

APP_NAME = "PomodoroWidget"

def get_settings_path():
    system = platform.system()
    if system == "Windows":
        return os.path.join(os.getenv('APPDATA'), APP_NAME, "settings.json")
    elif system == "Darwin":  # macOS
        return os.path.join(os.path.expanduser('~'), 'Library', 'Application Support', APP_NAME, "settings.json")
    else:  # Linux and other UNIX-like systems
        return os.path.join(os.path.expanduser('~'), '.config', APP_NAME, "settings.json")

SETTINGS_FILE = get_settings_path()

# Ensure the directory exists
os.makedirs(os.path.dirname(SETTINGS_FILE), exist_ok=True)

DEFAULT_SETTINGS = {
    "work_duration": 25,  # Default work duration in minutes
    "break_duration": 5,  # Default break duration in minutes
    "widget_location": {"x": 100, "y": 100},  # Default widget location
    "manual_mode": False  # Default mode is automatic
}

def load_settings():
    settings = DEFAULT_SETTINGS.copy()
    if os.path.exists(SETTINGS_FILE):
        with open(SETTINGS_FILE, "r") as f:
            loaded_settings = json.load(f)
            settings.update(loaded_settings)
    else:
        with open(SETTINGS_FILE, "w") as f:
            json.dump(DEFAULT_SETTINGS, f)
    return settings

def save_settings(settings):
    with open(SETTINGS_FILE, "w") as f:
        json.dump(settings, f)

class PomodoroTimer:
    def __init__(self, root):
        self.settings = load_settings()
        self.work_duration = self.settings["work_duration"]
        self.break_duration = self.settings["break_duration"]
        self.widget_location = self.settings["widget_location"]
        self.manual_mode = self.settings["manual_mode"]

        self.root = root
        self.root.title("Pomodoro Timer")
        self.root.geometry(f"+{self.widget_location['x']}+{self.widget_location['y']}")
        self.root.wm_attributes("-transparentcolor", "black")
        self.root.config(bg="black")
        self.root.overrideredirect(True)

        self.style = ttk.Style()
        self.style.configure("Dark.TFrame", background="black")
        self.style.configure("Dark.TLabel", background="black", foreground="white")

        self.timer_frame = ttk.Frame(root, style="Dark.TFrame")
        self.timer_frame.pack(fill=tk.BOTH, expand=True)

        self.time_var = tk.StringVar()
        self.time_var.set(f"{self.work_duration:02}:00")

        self.timer_label = ttk.Label(self.timer_frame, textvariable=self.time_var, style="Dark.TLabel", font=("Arial", 48, "bold"))
        self.timer_label.pack(pady=20)

        self.control_frame = ttk.Frame(self.timer_frame, style="Dark.TFrame")
        self.control_frame.pack(pady=5)

        self.start_pause_button = tk.Button(self.control_frame, text="Start", bg="black", fg="white", bd=2, relief="solid", command=self.toggle_timer)
        self.start_pause_button.pack(side=tk.LEFT, padx=5, pady=5)

        self.switch_button = tk.Button(self.control_frame, text="Switch", bg="black", fg="white", bd=2, relief="solid", command=self.switch_period)
        if self.manual_mode:
            self.switch_button.pack(side=tk.LEFT, padx=5, pady=5)

        self.timer_running = False
        self.is_work_period = True
        self.remaining_time = timedelta(minutes=self.work_duration)
        self.update_timer_label()

        self.menu = tk.Menu(root, tearoff=0)
        self.menu.add_command(label="Reset", command=self.reset_timer)
        self.menu.add_command(label="Settings", command=self.open_settings)
        self.menu.add_command(label="Exit", command=self.exit_program)
        self.root.bind("<Button-3>", self.show_menu)

        # Initialize pygame
        pygame.mixer.init()

    def toggle_timer(self):
        if self.manual_mode:
            if not self.timer_running:
                # Start the timer
                self.timer_running = True
                self.start_pause_button.config(text="Pause")
                self.countdown()
            else:
                # Pause the timer
                self.timer_running = False
                self.start_pause_button.config(text="Start")
        else:
            if self.timer_running:
                self.timer_running = False
                self.start_pause_button.config(text="Start")
            else:
                self.timer_running = True
                self.start_pause_button.config(text="Pause")
                self.countdown()

    def reset_timer(self):
        self.timer_running = False
        self.is_work_period = True
        self.remaining_time = timedelta(minutes=self.work_duration)
        self.update_timer_label()
        self.start_pause_button.config(text="Start")

    def countdown(self):
        if self.timer_running:
            if self.remaining_time > timedelta(0):
                self.remaining_time -= timedelta(seconds=1)
                self.update_timer_label()
                self.root.after(1000, self.countdown)
            else:
                self.timer_running = False
                self.play_sound()
                if not self.manual_mode:
                    self.switch_period()
                self.start_pause_button.config(text="Start")

    def switch_period(self):
        self.is_work_period = not self.is_work_period
        self.remaining_time = timedelta(minutes=self.break_duration if not self.is_work_period else self.work_duration)
        self.update_timer_label()

    def update_timer_label(self):
        total_seconds = int(self.remaining_time.total_seconds())
        minutes, seconds = divmod(total_seconds, 60)
        self.time_var.set(f"{minutes:02}:{seconds:02}")

    def open_settings(self):
        original_location = self.widget_location.copy()
        settings_window = tk.Toplevel(self.root)
        settings_window.title("Settings")
        settings_window.geometry("300x250")

        heading_label = ttk.Label(settings_window, text="Pomodoro Settings", font=("Arial", 12, "bold"))
        heading_label.grid(row=0, column=0, columnspan=2, pady=(10, 20))

        work_label = ttk.Label(settings_window, text="Work duration (minutes):")
        work_label.grid(row=1, column=0, sticky="w", padx=10)
        work_entry = ttk.Entry(settings_window)
        work_entry.grid(row=1, column=1, padx=10)

        break_label = ttk.Label(settings_window, text="Break duration (minutes):")
        break_label.grid(row=2, column=0, sticky="w", padx=10)
        break_entry = ttk.Entry(settings_window)
        break_entry.grid(row=2, column=1, padx=10)

        location_label = ttk.Label(settings_window, text="Widget location (x, y):")
        location_label.grid(row=3, column=0, sticky="w", padx=10)
        location_entry_frame = ttk.Frame(settings_window)
        location_entry_frame.grid(row=3, column=1, padx=10)

        location_entry_x = ttk.Entry(location_entry_frame, width=7)
        location_entry_x.pack(side=tk.LEFT, padx=(0, 5))

        location_entry_y = ttk.Entry(location_entry_frame, width=7)
        location_entry_y.pack(side=tk.LEFT)

        # Set default values for entries
        work_entry.insert(0, str(self.work_duration))
        break_entry.insert(0, str(self.break_duration))
        location_entry_x.insert(0, str(self.widget_location["x"]))
        location_entry_y.insert(0, str(self.widget_location["y"]))

        manual_mode_var = tk.BooleanVar()
        manual_mode_var.set(self.manual_mode)
        manual_mode_check = ttk.Checkbutton(settings_window, text="Countdown mode", variable=manual_mode_var)
        manual_mode_check.grid(row=4, column=0, columnspan=2, pady=10)

        def update_location_preview(event=None):
            try:
                x = int(location_entry_x.get())
                y = int(location_entry_y.get())
                self.update_widget_location(x, y)
            except ValueError:
                pass

        location_entry_x.bind("<KeyRelease>", update_location_preview)
        location_entry_y.bind("<KeyRelease>", update_location_preview)

        def save_settings():
            self.work_duration = int(work_entry.get())
            self.break_duration = int(break_entry.get())
            self.widget_location["x"] = int(location_entry_x.get())
            self.widget_location["y"] = int(location_entry_y.get())
            self.manual_mode = manual_mode_var.get()

            settings = {
                "work_duration": self.work_duration, 
                "break_duration": self.break_duration, 
                "widget_location": self.widget_location,
                "manual_mode": self.manual_mode
            }
            self.save_settings(settings)

            settings_window.destroy()
            self.update_widget_location(self.widget_location["x"], self.widget_location["y"])
            self.reset_timer()

            # Show or hide switch button based on manual mode
            if self.manual_mode:
                self.switch_button.pack(side=tk.LEFT, padx=5, pady=5)
            else:
                self.switch_button.pack_forget()

        def on_close():
            self.update_widget_location(original_location["x"], original_location["y"])
            settings_window.destroy()

        settings_window.protocol("WM_DELETE_WINDOW", on_close)

        save_button = ttk.Button(settings_window, text="Save", command=save_settings)
        save_button.grid(row=5, column=0, columnspan=2, pady=20)

    def save_settings(self, settings):
        with open(SETTINGS_FILE, "w") as f:
            json.dump(settings, f)

    def update_widget_location(self, x, y):
        self.root.geometry(f'+{x}+{y}')

    def exit_program(self):
        self.root.destroy()

    def show_menu(self, event):
        self.menu.post(event.x_root, event.y_root)

    def play_sound(self):
        pygame.mixer.music.load("retrocoin.mp3")
        pygame.mixer.music.play()

if __name__ == "__main__":
    root = tk.Tk()
    app = PomodoroTimer(root)
    root.mainloop()
