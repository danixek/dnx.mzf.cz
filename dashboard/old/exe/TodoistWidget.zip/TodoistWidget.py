import os
import tkinter as tk
from tkinter import ttk
from datetime import datetime, timedelta
import requests
import json
import subprocess
import platform

APP_NAME = "TodoistWidget"

def get_settings_path():
    system = platform.system()
    if system == "Windows":
        return os.path.join(os.getenv('APPDATA'), APP_NAME, "settings.json")
    elif system == "Darwin":  # macOS
        return os.path.join(os.path.expanduser('~'), 'Library', 'Application Support', APP_NAME, "settings.json")
    else:  # Linux and other UNIX-like systems
        return os.path.join(os.path.expanduser('~'), '.config', APP_NAME, "settings.json")

SETTINGS_FILE = get_settings_path()

# Ensure the directory exists
os.makedirs(os.path.dirname(SETTINGS_FILE), exist_ok=True)

DEFAULT_SETTINGS = {
    "API_KEY": "YOUR_API_KEY",
    "widget_location": {"x": 100, "y": 100}  # Default widget location
}

def load_settings():
    if os.path.exists(SETTINGS_FILE):
        with open(SETTINGS_FILE, "r") as f:
            return json.load(f)
    else:
        with open(SETTINGS_FILE, "w") as f:
            json.dump(DEFAULT_SETTINGS, f)
        return DEFAULT_SETTINGS

def save_settings(settings):
    with open(SETTINGS_FILE, "w") as f:
        json.dump(settings, f)

settings = load_settings()
API_KEY = settings["API_KEY"]
widget_location = settings["widget_location"]

def fetch_tasks():
    tasks_url = "https://api.todoist.com/rest/v2/tasks"
    tasks_response = requests.get(tasks_url, headers={"Authorization": f"Bearer {API_KEY}"})

    if tasks_response.status_code == 200:
        tasks = tasks_response.json()
        today = datetime.today().date().isoformat()
        todays_tasks = [task for task in tasks if task.get('due') and task['due']['date'] == today]
        sorted_tasks = sorted(todays_tasks, key=lambda x: datetime.fromisoformat(x['due']['datetime']).replace(tzinfo=None) if 'datetime' in x['due'] else datetime.max)
        return sorted_tasks
    else:
        print("Failed to load tasks:", tasks_response.status_code, tasks_response.reason)
        return []

def complete_task(task_id):
    complete_url = f"https://api.todoist.com/rest/v2/tasks/{task_id}/close"
    response = requests.post(complete_url, headers={"Authorization": f"Bearer {API_KEY}"})
    if response.status_code == 204:
        print(f"Task {task_id} marked as complete.")
        root.after(100, refresh_tasks)
    else:
        print(f"Failed to mark task {task_id} as complete.")

def get_time_color(task_due_time):
    current_time = datetime.now()
    if task_due_time:
        task_time = datetime.fromisoformat(task_due_time).replace(tzinfo=None)
        if task_time < current_time:
            return "#ff4444"  # Light red
        elif current_time <= task_time <= current_time + timedelta(minutes=10):
            return "#ffaa33"  # Light orange
        else:
            return "#55ff55"  # Light green
    return "white"  # No specific time

def update_tasks():
    tasks = fetch_tasks()
    for widget in tasks_frame.winfo_children():
        widget.destroy()  # Clear old tasks
    if tasks:
        for task in tasks:
            task_frame = ttk.Frame(tasks_frame, style="Dark.TFrame")
            task_frame.pack(fill=tk.X, pady=5)

            priority_colors = {1: "#333333", 2: "blue", 3: "orange", 4: "red"}
            priority_color = priority_colors.get(task['priority'], "black")
            priority_label = tk.Label(task_frame, text="●", font=("Arial", 25, "bold"), fg=priority_color, bg="black", cursor="hand2")
            priority_label.pack(side=tk.LEFT, padx=(10, 5))
            priority_label.bind("<Button-1>", lambda e, task_id=task['id']: complete_task(task_id))

            task_content = task['content']
            task_due_time = task['due']['datetime'] if 'datetime' in task['due'] else None
            if task_due_time:
                task_time_display = datetime.fromisoformat(task_due_time).strftime('%H:%M')
                time_color = get_time_color(task_due_time)
            else:
                task_time_display = 'No time'
                time_color = "white"

            task_label = ttk.Label(task_frame, text=task_content, style="Dark.TLabel", wraplength=280, font=("Arial", 10, "bold"))
            task_label.pack(side=tk.TOP, padx=10, anchor="w")
            time_label = ttk.Label(task_frame, text=task_time_display, style="Dark.TLabel", foreground=time_color, font=("Arial", 10, "bold"))
            time_label.pack(side=tk.TOP, padx=10, anchor="w")
    else:
        task_label = ttk.Label(tasks_frame, text="No tasks for today or failed to load tasks.", style="Dark.TLabel", wraplength=280, font=("Arial", 10, "bold"))
        task_label.pack(anchor='w', padx=10, pady=5)

def refresh_tasks():
    update_tasks()
    root.after(300000, refresh_tasks)  # Update every 5 minutes

def open_todoist():
    try:
        system = platform.system()
        if system == "Windows":
            os.startfile(os.path.join(os.getenv('LOCALAPPDATA'), "Programs", "todoist", "Todoist.exe"))
        elif system == "Darwin":  # macOS
            subprocess.run(["open", "-a", "Todoist"])
        else:  # Linux and other UNIX-like systems
            subprocess.run(["xdg-open", "todoist"])
    except Exception as e:
        print("Todoist application not found or could not be opened:", e)

def settings():
    settings_window = tk.Toplevel(root)
    settings_window.title("Settings")
    settings_window.geometry("300x150")

    # Heading for settings
    heading_label = ttk.Label(settings_window, text="Settings of Todoist widget", font=("Arial", 12, "bold"))
    heading_label.grid(row=0, column=0, columnspan=2, pady=(10, 20))

    # API key label and entry
    api_label = ttk.Label(settings_window, text="API key:")
    api_label.grid(row=1, column=0, sticky="w", padx=10)
    api_entry = ttk.Entry(settings_window)
    api_entry.grid(row=1, column=1, padx=10, sticky="e")

    # Set default API key value
    api_entry.insert(0, API_KEY)

    # Widget location label and entry
    location_label = ttk.Label(settings_window, text="Widget location (x, y):")
    location_label.grid(row=2, column=0, sticky="w", padx=10)
    location_entry_frame = ttk.Frame(settings_window)
    location_entry_frame.grid(row=2, column=1, padx=10, sticky="e")
    
    location_entry_x = ttk.Entry(location_entry_frame, width=7)
    location_entry_x.pack(side=tk.LEFT, padx=(0, 5))
    location_entry_x.insert(0, widget_location["x"])
    
    location_entry_y = ttk.Entry(location_entry_frame, width=7)
    location_entry_y.pack(side=tk.LEFT)
    location_entry_y.insert(0, widget_location["y"])

    def save_settings():
        global API_KEY
        global widget_location

        API_KEY = api_entry.get()
        widget_location["x"] = int(location_entry_x.get())
        widget_location["y"] = int(location_entry_y.get())

        settings = {"API_KEY": API_KEY, "widget_location": widget_location}

        with open(SETTINGS_FILE, "w") as f:
            json.dump(settings, f)

        settings_window.destroy()
        update_widget_location(widget_location["x"], widget_location["y"])  # Update live preview

    def live_update_widget_location(event):
        try:
            x = int(location_entry_x.get())
            y = int(location_entry_y.get())
            update_widget_location(x, y)
        except ValueError:
            pass  # Do nothing if value is not a valid number

    location_entry_x.bind("<KeyRelease>", live_update_widget_location)
    location_entry_y.bind("<KeyRelease>", live_update_widget_location)

    save_button = ttk.Button(settings_window, text="Save", command=save_settings)
    save_button.grid(row=3, column=0, columnspan=2, pady=20)

def update_widget_location(x, y):
    root.geometry(f'+{x}+{y}')

root = tk.Tk()
root.title("Todoist Tasks")
root.geometry(f"+{widget_location['x']}+{widget_location['y']}")  # Set widget location
root.wm_attributes("-transparentcolor", "black")  # Set black color as transparent
root.config(bg="black")  # Set background to black for transparency
root.overrideredirect(True)  # Remove window header

style = ttk.Style()
style.configure("Dark.TFrame", background="black")
style.configure("Dark.TLabel", background="black", foreground="white")

tasks_frame = ttk.Frame(root, style="Dark.TFrame")
tasks_frame.pack(fill=tk.BOTH, expand=True)

def exit_program():
    root.destroy()  # Exit the program when closed

menu = tk.Menu(root, tearoff=0)
menu.add_command(label="Open Todoist", command=open_todoist)
menu.add_command(label="Refresh", command=update_tasks)
menu.add_command(label="Settings", command=settings)
menu.add_command(label="Exit", command=exit_program)
menu.add_separator()

def show_menu(event):
    menu.post(event.x_root, event.y_root)

root.bind("<Button-3>", show_menu)  # Right-click to show menu

refresh_tasks()
root.mainloop()
